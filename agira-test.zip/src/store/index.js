import { combineReducers } from 'redux'
import commonReducer from '../service/reducer';

const rootReducer = combineReducers({
  commonReducer
});

export default rootReducer;