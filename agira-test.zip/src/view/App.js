import React, { Component } from 'react';

import Home from './home';

export default class App extends Component {
  render() {
    return (
      <Home/>
    );
  }
}

