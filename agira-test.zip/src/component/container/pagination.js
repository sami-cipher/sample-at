import React from 'react';

export default class Pagination extends React.Component {
  state = {
    
  }
}